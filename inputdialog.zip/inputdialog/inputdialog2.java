import javax.swing.JOptionPane;

class inputdialog2
{
	public static void main(String[] args) 
	{
		String a=JOptionPane.showInputDialog("Type Something Here","20");
		System.out.println(a);
	}
}