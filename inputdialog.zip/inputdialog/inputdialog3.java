import javax.swing.JOptionPane;

class inputdialog3
{
	public static void main(String[] args)
	{
		String a=JOptionPane.showInputDialog(null,"Type Something Here","InputBox",JOptionPane.INFORMATION_MESSAGE);
		System.out.println(a);
	}
}