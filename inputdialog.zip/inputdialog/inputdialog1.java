import javax.swing.JOptionPane;

class inputdialog1
{
	public static void main(String[] args) 
	{
		String a=JOptionPane.showInputDialog("Type Something Here");
		System.out.println(a);
	}
}