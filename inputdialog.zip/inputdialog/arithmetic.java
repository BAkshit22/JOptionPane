import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

class arithmetic
{
	public static void main(String[] args)
	{
	    int ans;
	    float ns;	
	Object[] options={"Addition","Subtraction","Division","Multiplication"};
        ImageIcon icon=new ImageIcon("cal.png");
        Object arit=JOptionPane.showInputDialog(null,"Choose One Operation","Aritmatic Box",JOptionPane.QUESTION_MESSAGE,
        icon,options,options[0]);
	    int num1=Integer.parseInt(JOptionPane.showInputDialog(null,"Enter Number 1 : "));
	  //  System.out.println(num1);
	    int num2=Integer.parseInt(JOptionPane.showInputDialog(null,"Enter Number 2 : "));   
        //System.out.println(num2);
        
        if(options[0]==arit)
        {
            ans=num1+num2;
            int input= JOptionPane.showConfirmDialog(null,"Answer = "+ans,"Addition",JOptionPane.DEFAULT_OPTION);
        System.out.println("Addition\t\t"+num1+" + "+num2+" = "+ans);
        }
        else if(options[1]==arit)
        {
              ans=num1-num2;
               int input= JOptionPane.showConfirmDialog(null,"Answer = "+ans,"Subtraction",JOptionPane.DEFAULT_OPTION);
        System.out.println("subtraction\t\t"+num1+" - "+num2+" = "+ans);  
        }
        else if(options[3]==arit)
        {
             ans=num1*num2;
              int input= JOptionPane.showConfirmDialog(null,"Answer = "+ans,"Multiplication",JOptionPane.DEFAULT_OPTION);
        System.out.println("Multiplication\t\t"+num1+" X "+num2+" = "+ans);   
        }
        else if (options[2]==arit) 
        {
             ns=num1/num2;
              int input= JOptionPane.showConfirmDialog(null,"Answer = "+ns,"Division",JOptionPane.DEFAULT_OPTION);
        System.out.println("Division\t\t"+num1+" / "+num2+" = "+ns);
        }
    }
}