import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

class inputdialog4
{
	public static void main(String[] args)
	{
        String[] options={"c","c++","java","python","HTML","css"};
        ImageIcon icon=new ImageIcon("giphy.gif");

        String a=(String)JOptionPane.showInputDialog(null,"Your Favr BCA Sub","Select Any One Sub",JOptionPane.QUESTION_MESSAGE
        	,icon,options,options[5]);
        System.out.println(a);
    }
}