import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

class inputdialog5
{
	public static void main(String[] args)
	{
		Object[] options={24,"Aksh",7.9,true};
		ImageIcon icon= new ImageIcon("giphy.gif");

		Object l=JOptionPane.showInputDialog(null,"Pick Any Datatype","Choose Your Way",JOptionPane.ERROR_MESSAGE
	    ,icon,options,options[1]);

	    if(l instanceof Integer) 
	    {
	    	System.out.println("You Choosed Integer");
	    }
	    else if(l instanceof Boolean) 
	    {
	    	System.out.println("You Choosed boolean");
	    }
	    else if(l instanceof String) 
	    {
	    	System.out.println("You Choosed String");
	    }
	    else
	    {
	    	System.out.println("You Choosed Double");
	    }	
	}
}