import javax.swing.JOptionPane;

class allmssg
{
	public static void main(String[] args)
	{
       JOptionPane.showMessageDialog(null,"Succesfully Updated","alert",JOptionPane.WARNING_MESSAGE);

       JOptionPane.showMessageDialog(null,"Succesfully Updated","alert",JOptionPane.PLAIN_MESSAGE);

       JOptionPane.showMessageDialog(null,"Succesfully Updated");

       JOptionPane.showMessageDialog(null,"Succesfully Updated","alert",JOptionPane.INFORMATION_MESSAGE);

       JOptionPane.showMessageDialog(null,"Succesfully Updated","alert",JOptionPane.ERROR_MESSAGE);
	}
}