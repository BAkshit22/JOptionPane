import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

class prime1
{
public static void main(String[] args)
   {
   	  int i,n;
   	  boolean p= false;
      Scanner a=new Scanner(System.in);
      System.out.print("\tEnter Value for checking Prime Number : ");n=a.nextInt();
      for (i=2;i<=n/2;i++) 
      {
         if (n% i == 0)
        {
        p = true;
        }
      }   
        if (!p) 
           {
       	    ImageIcon icon= new ImageIcon("giphy.gif");
            int input= JOptionPane.showConfirmDialog(null,"Your Number is prime Number","Is Your ANS Correct",JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,icon);
            System.out.println(input);
           }    
           else
           {
           	ImageIcon icon= new ImageIcon("giphy.gif");
            int input= JOptionPane.showConfirmDialog(null,"Your Number is not prime Number","Is Your ANS Correct",JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,icon);
            System.out.println(input);
           }
    }
}