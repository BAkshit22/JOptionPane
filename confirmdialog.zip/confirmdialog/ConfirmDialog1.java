import javax.swing.JOptionPane;

public class ConfirmDialog1
{
	public static void main(String[] args)
	{
		int input= JOptionPane.showConfirmDialog(null,"Do You Like Computers ?");
		System.out.println(input);
	}
}