import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class confirmdialog4
{
	public static void main(String[] args)
	{
		ImageIcon icon= new ImageIcon("giphy.gif");
		int input= JOptionPane.showConfirmDialog(null,"Click yes if you are in sy","All the Best",JOptionPane.YES_NO_OPTION,
		JOptionPane.ERROR_MESSAGE,icon);
		System.out.println(input);
	}
}